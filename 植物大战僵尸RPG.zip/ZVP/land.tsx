<?xml version="1.0" encoding="UTF-8"?>
<tileset name="land" tilewidth="32" tileheight="32" tilecount="42" columns="14">
 <image source="land.png" trans="000000" width="477" height="99"/>
</tileset>
