<?xml version="1.0" encoding="UTF-8"?>
<tileset name="brick" tilewidth="32" tileheight="32" tilecount="1" columns="1">
 <image source="brick_32px.png" trans="000000" width="32" height="32"/>
</tileset>
