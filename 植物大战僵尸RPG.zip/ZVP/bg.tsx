<?xml version="1.0" encoding="UTF-8"?>
<tileset name="bg" tilewidth="32" tileheight="32" tilecount="162" columns="18">
 <image source="buyecun.jpg" trans="000000" width="594" height="300"/>
</tileset>
